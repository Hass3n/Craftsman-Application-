package astbina.sanetna.Craftsman_details;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import astbina.sanetna.Dataclass.Datacrafstman;
import astbina.sanetna.R;

public class CraftsmanData extends AppCompatActivity {

    RecyclerView recyclerView;
    LinearLayoutManager linearLayoutManager;
    AdapterDetailsCraftsman Adapter;
    ArrayList<Datacrafstman>data;
    private static FirebaseDatabase database;
    private static DatabaseReference myRef=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_craftsman_data);
        recyclerView=findViewById(R.id.rc_craf_data);
        linearLayoutManager=new LinearLayoutManager(this);
        // read in firebase
       // database=FirebaseDatabase.getInstance();
       // myRef=database.getReference("Carfstman");
        add_data();

    }


    public void add_data()
    {
        database=FirebaseDatabase.getInstance();
        Intent intent = getIntent();
        int postion=intent.getIntExtra("position", 0);
        Log.e("postion",postion+"");
        switch (postion) {
        case 0:
            //myRef.child("Man");
         myRef=database.getReference("Carfstman").child("Man");
            break;
        case 1:
            myRef=database.getReference("Carfstman").child("Mano");
            break;
        case 2:
            //myRef.child("Manoi");
            myRef=database.getReference("Carfstman").child("Manoi");
            break;

        default:
          //  myRef.child("");
            myRef=database.getReference("ScholarshipsAndScientificAssignments ");
    }

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                data=new ArrayList<>();
                for (DataSnapshot dmo : dataSnapshot.getChildren())
                {
                    Datacrafstman datacrafstman=dmo.getValue(Datacrafstman.class);
                    String c_Name = datacrafstman.getName();
                    String C_photo = datacrafstman.getImagepersonal();
                    Log.e("e",c_Name);
                    data.add(0,new Datacrafstman(c_Name,C_photo,"","",""));


                }
                linearLayoutManager=new LinearLayoutManager(getApplicationContext());

                Adapter=new AdapterDetailsCraftsman(data,getApplicationContext());
                recyclerView.setLayoutManager(linearLayoutManager);
                recyclerView.setAdapter(Adapter);

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

                Toast.makeText(getApplicationContext(),databaseError.getMessage().toString(),Toast.LENGTH_LONG).show();

            }
        });


    }
}
