package astbina.sanetna.Dataclass;

public class Datacrafstman {

  private   String Name;
   private String imagepersonal;
   private String job;
   private  String Image_national_id;
   private  String Image_Cad_work;
    public Datacrafstman()
    {

    }

    public Datacrafstman(String name, String image, String job,String Image_national,String Image_wok) {
        Name = name;
        this.imagepersonal = image;
        this.job = job;
        this.Image_national_id=Image_national;
        this.Image_Cad_work=Image_wok;
    }

    public String getImage_national_id() {
        return Image_national_id;
    }

    public void setImage_national_id(String image_national_id) {
        Image_national_id = image_national_id;
    }

    public String getImage_Cad_work() {
        return Image_Cad_work;
    }

    public void setImage_Cad_work(String image_Cad_work) {
        Image_Cad_work = image_Cad_work;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getImagepersonal() {
        return imagepersonal;
    }

    public void setImagepersonal(String imagepersonal) {
        this.imagepersonal = imagepersonal;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }
}
