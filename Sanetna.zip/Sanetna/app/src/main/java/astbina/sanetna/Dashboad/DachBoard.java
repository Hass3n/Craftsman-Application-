package astbina.sanetna.Dashboad;


import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;

import astbina.sanetna.Craftsman_details.CraftsmanTypeFragment;
import astbina.sanetna.Craftsman_details.CraftsmanFragment;
import astbina.sanetna.R;
import astbina.sanetna.PostsWork.ViewPagerAdapter;

public class DachBoard extends AppCompatActivity {

    TabLayout tabMenu;
    ViewPager viewPager;
    Button btn_roh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dash);

        tabMenu     = findViewById(R.id.tabMenu);
        viewPager   = findViewById(R.id.viewPager);
//        btn_roh=findViewById(R.id.rohhhh);
//        btn_roh.setOnClickListener(this);
        setupViewPager(viewPager);

        tabMenu.setupWithViewPager(viewPager);
        viewPager.setCurrentItem(1);  // 0 = drink , 1=food
    }

    private void setupViewPager(ViewPager viewPager) {
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
       //
         adapter.addFragment(new CraftsmanTypeFragment(),"المنشورات");
        adapter.addFragment(new CraftsmanFragment(),"الحرفيين");
        viewPager.setAdapter(adapter);
    }

//    @Override
//    public void onClick(View v) {
//        Intent i=new Intent(this,Main2Activity.class);
//        startActivity(i);
//    }
}
