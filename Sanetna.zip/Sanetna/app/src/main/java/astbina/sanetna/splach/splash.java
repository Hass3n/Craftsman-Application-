package astbina.sanetna.splach;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import astbina.sanetna.Basic.BasicHome;
import astbina.sanetna.PostsWork.MyService;
import astbina.sanetna.R;

public class splash extends Activity {
    public static final String ACTION_START_SERVICE = "com.mind.simplelogin.MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash);

        Intent startIntent = new Intent(getApplicationContext(), MyService.class);
        startIntent.setAction(ACTION_START_SERVICE);
        startService(startIntent);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(splash.this, BasicHome.class));
                finish();
            }
        }, 3000);

    }
}
