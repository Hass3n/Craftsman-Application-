package astbina.sanetna.Dataclass;

public class PersonalDate {

   private String name;
   private String email;
   private String phoneNumbe;
   private String password;
   private String places;
   private String data;
   private String identitycad;
   private String Imageidentitycad;
   private String Imageidentitycadwork;
   private String Imagepersonal;
   private String type_c;


  public PersonalDate()
  {

  }
    public PersonalDate(String name, String email, String phoneNumbe, String password, String places, String data, String identitycad, String imageidentitycad, String imageidentitycadwork, String imagepersonal,String type_c) {
        this.name = name;
        this.email = email;
        this.phoneNumbe = phoneNumbe;
        this.password = password;
        this.places = places;
        this.data = data;
        this.identitycad = identitycad;
        Imageidentitycad = imageidentitycad;
        Imageidentitycadwork = imageidentitycadwork;
        Imagepersonal = imagepersonal;
        this.type_c=type_c;
    }

    public String getType_c() {
        return type_c;
    }

    public void setType_c(String type_c) {
        this.type_c = type_c;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumbe() {
        return phoneNumbe;
    }

    public void setPhoneNumbe(String phoneNumbe) {
        this.phoneNumbe = phoneNumbe;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPlaces() {
        return places;
    }

    public void setPlaces(String places) {
        this.places = places;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getIdentitycad() {
        return identitycad;
    }

    public void setIdentitycad(String identitycad) {
        this.identitycad = identitycad;
    }

    public String getImageidentitycad() {
        return Imageidentitycad;
    }

    public void setImageidentitycad(String imageidentitycad) {
        Imageidentitycad = imageidentitycad;
    }

    public String getImageidentitycadwork() {
        return Imageidentitycadwork;
    }

    public void setImageidentitycadwork(String imageidentitycadwork) {
        Imageidentitycadwork = imageidentitycadwork;
    }

    public String getImagepersonal() {
        return Imagepersonal;
    }

    public void setImagepersonal(String imagepersonal) {
        Imagepersonal = imagepersonal;
    }
}
