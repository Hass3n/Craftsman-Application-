package astbina.sanetna.Craftsman_details;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

import astbina.sanetna.Dataclass.Datacrafstman;
import astbina.sanetna.R;

public class AdapterDetailsCraftsman extends RecyclerView.Adapter<AdapterDetailsCraftsman.ViewHolder> {
    List<Datacrafstman> data_items;
    Context context;


    public AdapterDetailsCraftsman(List<Datacrafstman> data_items, Context context) {
        this.data_items= data_items;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.view_more_food,viewGroup,false);
        ViewHolder viewHolder = new ViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {

        final Datacrafstman item= data_items.get(i);
        viewHolder.txt1.setText(item.getName());


        String imagephoto= item.getImagepersonal();
        Log.e("photo",imagephoto+"");
        if (imagephoto.isEmpty())
        {
            // Picasso.get().load(R.drawable.ic_launcher_foreground).into( viewHolder.book_image);
            viewHolder.imag.setImageResource(R.drawable.banna);
        }
        else
        {
            Picasso.get().load(imagephoto).into( viewHolder.imag);
        }




    }

    @Override
    public int getItemCount() {
        return data_items.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView txt1;
        ImageView imag;
        View parent;

        ViewHolder(View view){
            super(view);
            txt1= view.findViewById(R.id.tvNameFood);
            imag = view.findViewById(R.id.img);
            parent=view;

        }
    }



}
